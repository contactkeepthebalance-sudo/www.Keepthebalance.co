# KTB E-commerce — With Admin Dashboard & Cloudinary Uploads

This upgraded starter includes:
- Admin dashboard (`/admin.html`) to add products and upload images to Cloudinary.
- Backend upload endpoint (`/api/uploads`) that stores images on Cloudinary and returns secure CDN URLs.
- Keep using Paystack for payments.

## Quick setup
1. Run `npm install`.
2. Create `.env` from `.env.example` and add values:
   - MONGODB_URI, JWT_SECRET
   - PAYSTACK_SECRET_KEY, PAYSTACK_PUBLIC_KEY, PAYSTACK_CALLBACK_URL
   - CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET
3. Start server: `node server.js`
4. Visit:
   - Frontend: `http://localhost:3000/`
   - Admin dashboard: `http://localhost:3000/admin.html`

## Replacing images
- The admin dashboard uploads images to Cloudinary and returns secure URLs you can use in product image fields.
- You can also edit `public/js/main.js` to point to CDN URLs directly.

