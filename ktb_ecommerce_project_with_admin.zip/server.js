/*
  server.js - Node/Express backend upgraded with Cloudinary upload endpoint
*/
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());
app.use(cors());
app.use(express.static('public'));

const MONGODB = process.env.MONGODB_URI || 'mongodb://localhost:27017/ktb_ecom';
mongoose.connect(MONGODB, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(()=> console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

const Product = require('./models/Product');
const Order = require('./models/Order');
const User = require('./models/User');

// --- Cloudinary + multer setup ---
const cloudinary = require('cloudinary').v2;
const { CloudinaryStorage } = require('multer-storage-cloudinary');
const multer = require('multer');

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME || '',
  api_key: process.env.CLOUDINARY_API_KEY || '',
  api_secret: process.env.CLOUDINARY_API_SECRET || ''
});

// Storage that uploads directly to Cloudinary
const storage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: 'ktb_products',
    allowed_formats: ['jpg','png','jpeg','webp'],
    transformation: [{ width: 1200, crop: 'limit' }]
  }
});
const upload = multer({ storage });

// Upload endpoint
app.post('/api/uploads', upload.single('image'), (req,res)=>{
  // Returns object with url and secure_url
  if(!req.file) return res.status(400).json({ error: 'No file uploaded' });
  res.json({ url: req.file.path, public_id: req.file.filename, raw: req.file });
});

// Simple product routes (create via admin)
app.post('/api/products', async (req,res)=>{
  try{
    const p = new Product(req.body);
    await p.save();
    res.json(p);
  }catch(e){ res.status(400).json({ error: e.message }) }
});

app.get('/api/products', async (req,res)=>{
  try{
    const products = await Product.find().sort({ createdAt: -1 });
    res.json(products);
  }catch(e){ res.status(500).json({ error: 'db error' }) }
});

// Orders & Paystack skeleton (same as before)
const axios = require('axios');
const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY || 'sk_test_xxx';
const PAYSTACK_CALLBACK = process.env.PAYSTACK_CALLBACK_URL || '';

app.post('/api/orders', async (req,res)=>{
  try{
    const order = new Order(req.body);
    await order.save();
    res.json(order);
  }catch(e){ res.status(400).json({ error: e.message }) }
});

app.post('/api/payments/initialize', async (req,res)=>{
  try{
    const { email, amount, orderId } = req.body;
    const response = await axios.post('https://api.paystack.co/transaction/initialize', {
      email,
      amount: Math.round(amount * 100),
      callback_url: PAYSTACK_CALLBACK
    }, {
      headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY || ''}` }
    });
    res.json(response.data);
  }catch(e){
    console.error(e.response && e.response.data ? e.response.data : e.message);
    res.status(500).json({ error: 'paystack init failed' });
  }
});

app.post('/api/payments/verify', async (req,res)=>{
  try{
    const { reference } = req.body;
    const response = await axios.get(`https://api.paystack.co/transaction/verify/${reference}`, {
      headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY || ''}` }
    });
    res.json(response.data);
  }catch(e){
    res.status(500).json({ error: 'paystack verify failed' });
  }
});

app.post('/api/payments/webhook', async (req,res)=>{
  console.log('Webhook payload:', req.body);
  res.sendStatus(200);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server running on port', PORT));
