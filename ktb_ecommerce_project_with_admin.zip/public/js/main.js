// main.js fetches products from server
async function loadProducts(){
  const res = await fetch('/api/products');
  const products = await res.json();
  const productsEl = document.getElementById('products');
  productsEl.innerHTML = '';
  products.forEach(p=>{
    const div = document.createElement('div');
    div.className = 'card';
    div.innerHTML = `
      <img src="${p.image || 'images/placeholder/product1.jpg'}" alt="${p.title}" />
      <h3>${p.title}</h3>
      <p>${p.description}</p>
      <p>₦${p.price.toLocaleString()}</p>
      <button class="button" onclick='addToCart("${p._id}")'>Add to cart</button>
    `;
    productsEl.appendChild(div);
  });
}
let cart = {};
function addToCart(id){
  // find product (simple)
  fetch('/api/products').then(r=>r.json()).then(products=>{
    const p = products.find(x=>x._id===id);
    if(!p) return alert('product not found');
    if(!cart[id]) cart[id] = {...p, qty:0};
    cart[id].qty++;
    renderCart();
  });
}
function renderCart(){
  const cartItemsEl = document.getElementById('cart-items');
  cartItemsEl.innerHTML = '';
  const keys = Object.keys(cart);
  if(keys.length===0){ cartItemsEl.innerHTML = '<p>Cart is empty</p>'; return; }
  let total = 0;
  keys.forEach(k=>{
    const it = cart[k];
    total += it.price * it.qty;
    const div = document.createElement('div');
    div.innerHTML = `<strong>${it.title}</strong> x ${it.qty} — ₦${(it.price*it.qty).toLocaleString()}`;
    cartItemsEl.appendChild(div);
  });
  const tot = document.createElement('div');
  tot.style.marginTop = '8px';
  tot.innerHTML = `<strong>Total: ₦${total.toLocaleString()}</strong>`;
  cartItemsEl.appendChild(tot);
}
document.getElementById('checkout-btn').addEventListener('click', async ()=>{
  const email = document.getElementById('email').value;
  if(!email) return alert('Please enter email');
  const items = Object.values(cart).map(it=>({ productId: it._id, title: it.title, qty: it.qty, price: it.price }));
  const amount = items.reduce((s,i)=>s + i.price*i.qty, 0);
  const orderRes = await fetch('/api/orders', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ orderId: 'ord_' + Date.now(), items, amount, status: 'pending' })
  });
  const order = await orderRes.json();
  const init = await fetch('/api/payments/initialize', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ email, amount, orderId: order.orderId })
  });
  const initJson = await init.json();
  if(initJson && initJson.data && initJson.data.authorization_url){
    window.location.href = initJson.data.authorization_url;
  } else {
    alert('Payment initialization failed.');
  }
});
loadProducts();
