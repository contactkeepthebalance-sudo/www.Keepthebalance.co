// admin.js - handles image upload to server (Cloudinary) and product creation
const form = document.getElementById('product-form');
const imageInput = document.getElementById('image');
const imageUrlInput = document.getElementById('image-url');
const statusEl = document.getElementById('status');
const adminProducts = document.getElementById('admin-products');

async function uploadImage(file){
  const fd = new FormData();
  fd.append('image', file);
  const res = await fetch('/api/uploads', { method: 'POST', body: fd });
  return res.json();
}

form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  statusEl.textContent = 'Creating product...';
  const data = new FormData(form);
  let imageUrl = imageUrlInput.value;
  if(imageInput.files && imageInput.files[0]){
    statusEl.textContent = 'Uploading image...';
    const up = await uploadImage(imageInput.files[0]);
    if(up && up.url) imageUrl = up.url;
    else { statusEl.textContent = 'Image upload failed'; return; }
  }
  const payload = {
    title: data.get('title'),
    description: data.get('description'),
    price: Number(data.get('price')),
    category: data.get('category'),
    image: imageUrl
  };
  const res = await fetch('/api/products', {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload)
  });
  if(res.ok){ statusEl.textContent = 'Product created'; form.reset(); loadAdminProducts(); }
  else{ statusEl.textContent = 'Failed to create product'; }
});

async function loadAdminProducts(){
  const res = await fetch('/api/products');
  const products = await res.json();
  adminProducts.innerHTML = '';
  products.forEach(p=>{
    const div = document.createElement('div');
    div.className = 'card';
    div.innerHTML = `
      <img src="${p.image || 'images/placeholder/product1.jpg'}" />
      <h4>${p.title}</h4>
      <p>₦${p.price.toLocaleString()}</p>
    `;
    adminProducts.appendChild(div);
  });
}
loadAdminProducts();
